<div class="row">
    <div class="sidebar col-3">
        <ul>
            <li>
                <a href="<?php echo BASE_URL . "admin/posts/index.php"; ?>">Записи</a>
            </li>
            <li>
                <a href="<?php echo BASE_URL . "admin/topics/index.php"; ?>">Категорії</a>
            </li>
            <li>
                <a href="<?php echo BASE_URL . "admin/users/index.php"; ?>">Користувачі</a>
            </li>
            <li>
                <a href="<?php echo BASE_URL . "admin/comments/index.php"; ?>">Відгуки</a>
            </li>
        </ul>
    </div>