<?php include("path.php")?>
  <!-- START HEADER-->
  <?php include("app/include/header.php")?>
  <!-- END HEADER-->
    
<!-- Блок MAIN START-->
<div class="container">
  <div class="content row">
    <div class="main-content col-md-9 col-12 ">
      <h2>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Adipisci, cumque.</h2>

      <div class="single_post row">
        <div class="img col-12">
          <img src="assets/images/image_1.png" alt="" class="img-thumbnail">
        </div>
        <div class="info">
            <i class="far fa-user"> Имя Автора</i>
            <i class="far fa-calendar"> Mar 11, 2204</i>
        </div>
        <div class="single_post_text col-12">          
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe <a href="#">nobis</a> nobis dolore molestiae corrupti recusandae iure pariatur commodi quos facilis sit, dolorem repudiandae distinctio ducimus cupiditate eius? Fuga facere vero consequuntur, eaque, excepturi nihil earum eveniet pariatur fugiat id iste dignissimos animi ullam quaerat numquam. Esse magni optio totam, perferendis reprehenderit sequi, ab quisquam quas, nulla provident saepe ex beatae veniam sed maxime nisi expedita quaerat quidem consequatur! Modi consequuntur nihil voluptatem minus accusantium, earum quasi alias fugiat commodi doloribus similique expedita quia! Eos iste aliquam dolorum ad commodi soluta, nam nemo modi assumenda provident? Saepe dolor veritatis cupiditate quo.
        </div>
      </div>
      
    </div>
    <div class="sidebar col-md-3 col-12">
      <div class="section search">
        <h3>Поиск</h3>
        <form action="/" method="post">
          <input type="text" name="search-term" class="text-input" placeholder="Search...">
        </form>
      </div>

      <div class="section topics">
        <h3>Категории</h3>
        <ul>      
            <li><a href="#">Poems</a></li>
            <li><a href="#">Quotes</a></li>
            <li><a href="#">Fiction</a></li>
            <li><a href="#">Biography</a></li>
            <li><a href="#">Motivation</a></li>
            <li><a href="#">Inspiration</a></li>
            <li><a href="#">Life Lessons</a></li>
        </ul>
      </div>

    </div>
  </div>
</div>

<!-- FINISH block MAIN-->
<!-- START FOOTER -->
<?php include("app/include/footer.php") ?>
<!-- FINISH FOOTER -->
