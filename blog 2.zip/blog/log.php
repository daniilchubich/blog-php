<?php include("path.php")?>
    <!-- START HEADER-->
    <?php include("app/include/header.php")?>
    <!-- END HEADER-->
    <!-- START FORM-->
<div class="container reg_form">


    <form action="log.html" method="post" class="row justify-content-center">
        <h2>Авторизация</h2>
        <div class="mb-3 col-12 col-md-4 err">
            <p></p>
        </div>
        <div class="w-100"></div>
        <div class="mb-3 col-12 col-md-4">
            <label for="formGroupExampleInput" class="form-label">Ваш логин</label>
            <input name="login" value="" type="text" class="form-control" id="formGroupExampleInput" placeholder="введите ваш логин...">
        </div>
        <div class="w-100"></div>
        <div class="mb-3 col-12 col-md-4">
            <label for="exampleInputPassword1" class="form-label">Пароль</label>
            <input name="pass-first" type="password" class="form-control" id="exampleInputPassword1" placeholder="введите ваш пароль...">
        </div>
        <div class="w-100"></div>
        <div class="mb-3 col-12 col-md-4">
            <button type="submit" class="btn btn-secondary" name="button-reg">Войти</button>
            <a href="reg.html">Зарегистрироваться</a>
        </div>
    </form>




</div>
<!-- END FORM-->
<!-- START FOOTER-->
<? include("app/include/footer.php");?>
<!-- FINISH FOOTER-->
