<?php
include("app/database/db.php");
    
$isSubmit = false;
$errMsg = '';

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['button-reg'])){
    $admin = 0;
    $login = trim($_POST['login']);
    $email = trim($_POST['mail']);
    $passF = trim($_POST['pass-first']);
    $passS = trim($_POST['pass-second']);

    if($login === '' || $email === '' || $passF === ''){
       $errMsg = "Не все поля заполнены!";
    }else{
        $post = [
           'admin' => $admin,
           'username' => $login,
           'email' => $email,
           'password' => $passS
        ];
        $isSubmit = true;
        tt($post);
    }
    // $id = insert('users', $post);
    // $last_row = selectOne('users', ['id'=>$id]);
    // tt($last_row);
}else{
    echo "GET";
}


    
?>