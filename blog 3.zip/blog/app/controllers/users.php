<?php
include("app/database/db.php");
//include("path.php");

function userAuth($user){
    $_SESSION['id'] = $user['id'];
    $_SESSION['login'] = $user['username'];
    $_SESSION['admin'] = $user['admin'];
    if($_SESSION['admin']){
        header('location: ' . BASE_URL . "admin/admin.php");
    }else{
        header('location: ' . BASE_URL);
    }
}
$errMsg = '';

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['button-reg'])){
    $admin = 0;
    $login = trim($_POST['login']);
    $email = trim($_POST['mail']);
    $passF = trim($_POST['pass-first']);
    $passS = trim($_POST['pass-second']);

    if($login === '' || $email === '' || $passF === ''){
       $errMsg = "Не все поля заполнены!";
    }elseif (mb_strlen($login, 'UTF8') < 2){
        //array_push($errMsg, "Логин должен быть более 2-х символов");
        $errMsg = "Логин должен быть больше двух символов";
    }elseif ($passF !== $passS) {
        // array_push($errMsg, "Пароли в обеих полях должны соответствовать!");
        $errMsg = "Пароли в обеих полях должны соответствовать!";
    }else{ 
        $existence = selectOne('users', ['email' => $email]);
        if($existence['email'] === $email){
            // array_push($errMsg, "Пользователь с такой почтой уже зарегистрирован!");
            $errMsg = "Пользователь с такой почтой уже зарегистрирован!";
        }else{
            $pass = password_hash($passF, PASSWORD_DEFAULT);
            $post = [
                'admin' => $admin,
                'username' => $login,
                'email' => $email,
                'password' => $pass
            ];
            $id = insert('users', $post);
            $user = selectOne('users', ['id' => $id] );
            userAuth($user);
        }
    }
}else{
    $login = '';
    $email = '';
}

// $_SESSION['login_attempts'] = 0;
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['button-log'])){
    //  unset($_SESSION['login_attempts']);
    //  die();
    $email = trim($_POST['mail']);
    $pass = trim($_POST['password']);
    //tt($time_left_end);
    //tt($time_left_end);
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 0;
        $_SESSION['time_left_end'] = 0;
    }
    $_SESSION['login_attempts'] = isset($_SESSION['login_attempts']) ? $_SESSION['login_attempts']+1 : 1;
    if($_SESSION['login_attempts'] == MAX_ATTEMPTS_AUTH){
        if(time() < $_SESSION['time_left_end']){
            $time_left = $_SESSION['time_left_end'] - time();
            $errMsg = "Превышено количество попыток авторизации. Попробуйте снова через " . ceil($time_left / 60) . " минут.";
        }
    }
    elseif($_SESSION['login_attempts'] > MAX_ATTEMPTS_AUTH){
        if(time() < $_SESSION['time_left_end']){
            $time_left = $_SESSION['time_left_end'] - time(); //55900 
            $errMsg = "Превышено количество попыток авторизации. Попробуйте снова через " . ceil($time_left / 60) . " минут.";
        }
    }
    elseif($email === '' || $pass === '') {
            // array_push($errMsg, "Не все поля заполнены!");
            $errMsg = "Не все поля заполнены";
    }else{
        $existence = selectOne('users', ['email' => $email]);
        if($existence && password_verify($pass, $existence['password'])){
            userAuth($existence);
            unset($_SESSION['login_attempts'], $_SESSION['block_end_time']);
        }else{
            // array_push($errMsg, "Почта либо пароль введены неверно!");
            $errMsg =  "Почта либо пароль введены неверно!";
            //tt($_SESSION['login_attempts']);
            if(!isset($time_left_end)){
                $_SESSION['time_left_end'] = time() + BLOCK_TIME;  //55600+300=55900
            }
        }
    }
    }else{
        $email = '';
    }

    
?>