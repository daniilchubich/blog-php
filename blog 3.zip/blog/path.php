<?php
define("BASE_URL", "http://localhost/blog/");
define("BLOCK_TIME", 300); // время блокировки при повторных авторизациях
define("MAX_ATTEMPTS_AUTH", 3); // время блокировки при повторных авторизациях
?>